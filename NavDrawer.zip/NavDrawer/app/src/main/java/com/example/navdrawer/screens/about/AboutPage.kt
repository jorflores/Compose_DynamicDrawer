package com.example.navdrawer.screens.about

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun AboutPage() {

    Column {
        Text(text = "Welcome to AboutPage")
    }
}