package com.example.navdrawer.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import com.example.navdrawer.AppViewModel

@Composable
fun SettingsPage(viewModel: AppViewModel) {


    Column {
        Text(text = "Welcome to SettingsPage")
        Button(onClick = { viewModel.setLoggedIn()


        }) {
            Text("Log In")
        }
        Button(onClick = { viewModel.setLoggedOut() }) {
            Text("Log Out")
        }
    }
}